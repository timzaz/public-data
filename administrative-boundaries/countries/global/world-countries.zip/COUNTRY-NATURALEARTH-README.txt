Downloaded from Natural Earth repository
