Derived from Open Street Map via GeoFabrik
