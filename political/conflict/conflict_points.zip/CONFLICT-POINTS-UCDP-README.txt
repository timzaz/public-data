Downloaded from http://ucdp.uu.se/ged/data.php

Metadata can be found here:  http://ucdp.uu.se/ged/data/ucdp-ged-points-v-1-5-codebook.pdf

Covers Africa and Asia.
